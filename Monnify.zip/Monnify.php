<?php
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);

    //echo'soemthing';    

    $bank_name =$_GET['bank_name'];
    $amount =$_GET['amount'];
    $phone = $_GET['phone'];
    $customer_name = $_GET['customer_name'];

function index($bank_name, $amount, $phone, $customer_name){
    $acc_num = get_invoice($amount, $phone, $customer_name);
    $details = get_details($bank_name, $amount, $acc_num['acc_no']);

    if($details){
        $response = [
            'status_code'=> 0,
            'status'=>'success',
            'customer_name'=> $customer_name,
            'reference'=>$acc_num['ref'],
            'phone'=>$phone,
            'ussdTemplate'=>$details
        ];
        return json_encode($response);
    }else{
        $response = [
            'status_code'=> 1,
            'status'=>'failed',
        ];
        return json_encode($response);
    }
    

}


function get_details($bank_name, $amount, $Accountnumber){
        $handle = curl_init();
        $url = 'https://sandbox.monnify.com/api/v1/sdk/transactions/banks';
         
        // Set the url
        curl_setopt($handle, CURLOPT_URL, $url);
        curl_setopt($handle, CURLOPT_POST,false);
        // Set the result output to be a string.
        curl_setopt($handle, CURLOPT_RETURNTRANSFER, true);
         
        $output = curl_exec($handle);

        $result = json_decode($output);
        $error =  curl_error($handle);
        curl_close($handle);
         
        //echo $output;
        //var_dump($result->responseBody);
        //get USSD code
        $bank_codes = $result->responseBody;
        foreach ($bank_codes as $bankcode) {
            if ($bankcode['name'] == $bank_name){
                $temp = $bankcode['ussdTemplate'];

                $first = str_replace("Amount",$amount,$temp);

                $strr = str_replace("AccountNumber",$Accountnumber,$first);
                return $strr;
            }
        }
}

function get_invoice($amount, $phone, $customer_name){
    $url = 'https://sandbox.monnify.com/api/v1/invoice/create';
    $invoice_no = rand(1000000000, 9999999999);
    $fields = [
        "amount"=>$amount,
        "invoiceReference"=>$invoice_no,
        "description"=>"test invoice",
        "currencyCode"=>"NGN",
        "contractCode"=>"6812976159",
        "customerEmail"=>"tech-support@novajii.com",
        "customerName"=>$customer_name,
        "expiryDate"=> date('Y-m-d h:i:s',time() + 10),
        "paymentMethods"=>"ACCOUNT_TRANSFER",
    ];

    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_POST, true);
    curl_setopt($curl, CURLOPT_POSTFIELDS, json_encode($fields));
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

    $output = curl_exec($curl);
    $result = json_decode($output);

    $err = curl_error($curl);

    curl_close($curl);

    if($result->responseCode == 0){
        $response = [
            'ref' => $invoice_no,
            'acc_no' => $result->responseBody->accountNumber
        ];
        return $response;
    }

}

?>